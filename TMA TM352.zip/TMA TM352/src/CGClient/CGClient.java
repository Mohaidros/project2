package CGClient;

public class CGClient {

	public static void main(String[] args) {
		new ComplaintGUI();

	}

}